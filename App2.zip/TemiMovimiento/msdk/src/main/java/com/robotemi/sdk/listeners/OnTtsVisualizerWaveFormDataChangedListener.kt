package com.robotemi.sdk.listeners

interface OnTtsVisualizerWaveFormDataChangedListener {
    fun onTtsVisualizerWaveFormDataChanged(waveForm: ByteArray)
}