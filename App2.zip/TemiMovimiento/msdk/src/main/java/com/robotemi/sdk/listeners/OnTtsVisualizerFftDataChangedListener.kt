package com.robotemi.sdk.listeners

interface OnTtsVisualizerFftDataChangedListener {
    fun onTtsVisualizerFftDataChanged(fft: ByteArray)
}