package com.robotemi.sdk.face

interface OnContinuousFaceRecognizedListener {
    fun onContinuousFaceRecognized(contactModelList: List<ContactModel>)
}