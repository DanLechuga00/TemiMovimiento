package com.robotemi.sdk.face

interface OnFaceRecognizedListener {
    fun onFaceRecognized(contactModelList: List<ContactModel>)
}