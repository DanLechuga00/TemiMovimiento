package com.robotemi.sdk.listeners

interface OnMovementVelocityChangedListener {
    fun onMovementVelocityChanged(velocity: Float)
}